# Agent 架构设计 - 基础概念（续）

## Q45: Agent 有哪些分类类型？各类型的特点和应用场景是什么？

### 专业版答案

#### Agent 分类体系

**按自主性分类**：
- 反应式Agent（Reactive）
- 主动式Agent（Deliberative）
- 混合式Agent（Hybrid）

**按能力分类**：
- 单能力Agent（Single-capability）
- 多能力Agent（Multi-capability）
- 全能型Agent（General）

**按协作模式分类**：
- 独立Agent（Stand-alone）
- 协作Agent（Collaborative）
- 竞争Agent（Competitive）

---

#### 1. 按自主性分类

```python
# 反应式Agent（Reactive Agent）
class ReactiveAgent:
    """反应式Agent - 直接响应，不规划"""
    
    def __init__(self):
        self.rules = {
            "下雨": "提醒带伞",
            "高温": "提醒防晒",
            "低温": "提醒保暖"
        }
    
    def respond(self, stimulus):
        """直接反应"""
        # 不思考，直接响应
        
        # 查找规则
        for condition, action in self.rules.items():
            if self.matches(stimulus, condition):
                return action
        
        # 没有匹配规则 → 默认响应
        return "默认响应"
    
    # 特点：
    # - 快速响应（无需规划）
    # - 简单场景适用
    # - 无法处理复杂情况
    # - 无记忆能力
    
    # 应用场景：
    # - 简单客服（FAQ自动回复）
    # - 智能家居（传感器触发）
    # - 游戏NPC（固定反应）


# 主动式Agent（Deliberative Agent）
class DeliberativeAgent:
    """主动式Agent - 规划后行动"""
    
    def __init__(self):
        self.goal = None
        self.plan = []
        self.beliefs = {}
    
    def act(self, situation):
        """规划后行动"""
        # 1. 更新信念（理解当前情况）
        self.update_beliefs(situation)
        
        # 2. 设定目标
        self.set_goal(situation)
        
        # 3. 制定计划
        self.plan = self.create_plan()
        
        # 4. 执行计划
        result = self.execute_plan()
        
        # 5. 评估结果
        self.evaluate_result(result)
        
        return result
    
    def create_plan(self):
        """制定计划"""
        # 思考：如何达成目标
        
        plan_prompt = f"""
        当前信念：{self.beliefs}
        目标：{self.goal}
        
        制定行动计划：
        1. 分析目标要求
        2. 确定实现步骤
        3. 评估可行性
        4. 制定具体方案
        
        输出计划：
        """
        
        plan = llm.invoke(plan_prompt)
        
        return plan
    
    # 特点：
    # - 有规划能力
    # - 能处理复杂情况
    # - 有记忆和信念系统
    # - 响应较慢（需要规划）
    
    # 应用场景：
    # - 复杂客服（问题诊断+方案推荐）
    # - 项目助手（任务规划+执行）
    # - 机器人（路径规划+导航）


# 混合式Agent（Hybrid Agent）
class HybridAgent:
    """混合式Agent - 反应+规划结合"""
    
    def __init__(self):
        self.reactive_module = ReactiveModule()
        self.deliberative_module = DeliberativeModule()
    
    def act(self, situation):
        """混合决策"""
        # 1. 快速评估紧急程度
        urgency = self.assess_urgency(situation)
        
        if urgency == "high":
            # 紧急情况 → 反应式（快速）
            return self.reactive_module.respond(situation)
        
        else:
            # 不紧急 → 主动式（规划）
            return self.deliberative_module.act(situation)
    
    def assess_urgency(self, situation):
        """评估紧急程度"""
        # 判断是否需要立即响应
        
        urgent_conditions = [
            "安全威胁",
            "紧急请求",
            "时间紧迫"
        ]
        
        for condition in urgent_conditions:
            if self.matches(situation, condition):
                return "high"
        
        return "normal"
    
    # 特点：
    # - 兼顾速度和质量
    # - 紧急情况快速响应
    # - 复杂情况深度规划
    # - 最实用
    
    # 应用场景：
    # - 智能客服（FAQ快速+复杂规划）
    # - 个人助手（日常快速+复杂规划）
    # - 大多数实际应用
```

---

#### 2. 按能力分类

```python
# 单能力Agent（Single-capability Agent）
class SingleCapabilityAgent:
    """单能力Agent - 只擅长一件事"""
    
    def __init__(self):
        self.capability = "weather_query"  # 只能查天气
    
    def process(self, request):
        """处理请求"""
        # 只处理天气查询
        
        if self.is_weather_request(request):
            # 执行天气查询
            return self.query_weather(request)
        
        else:
            # 其他请求无法处理
            return "无法处理，请联系其他Agent"
    
    def is_weather_request(self, request):
        """判断是否天气请求"""
        weather_keywords = ["天气", "温度", "降雨", "晴天"]
        
        return any(keyword in request for keyword in weather_keywords)
    
    # 特点：
    # - 专业聚焦（只做一件事）
    # - 质量高（专精）
    # - 能力有限（其他事不能做）
    # - 成本低（简单）
    
    # 应用场景：
    # - 专项助手（天气Agent、翻译Agent、计算Agent）
    # - 工具型Agent（专做一件事）
    # - Agent团队中的专家


# 多能力Agent（Multi-capability Agent）
class MultiCapabilityAgent:
    """多能力Agent - 能做多件事"""
    
    def __init__(self):
        self.capabilities = {
            "weather_query": WeatherQueryCapability(),
            "translation": TranslationCapability(),
            "calculation": CalculationCapability(),
            "search": SearchCapability()
        }
    
    def process(self, request):
        """处理请求"""
        # 1. 分析请求需要什么能力
        required_capabilities = self.analyze_required_capabilities(request)
        
        # 2. 检查是否具备能力
        available = []
        unavailable = []
        
        for cap in required_capabilities:
            if cap in self.capabilities:
                available.append(cap)
            else:
                unavailable.append(cap)
        
        # 3. 执行可用能力
        results = {}
        
        for cap in available:
            results[cap] = self.capabilities[cap].execute(request)
        
        # 4. 处理不可用能力
        if unavailable:
            results["unavailable"] = f"缺少能力：{unavailable}"
        
        return results
    
    def analyze_required_capabilities(self, request):
        """分析需要的能力"""
        # 看请求需要哪些能力
        
        analyze_prompt = f"""
        请求：{request}
        
        分析需要的能力：
        1. 天气查询
        2. 翻译
        3. 计算
        4. 搜索
        
        输出需要的能力列表：
        """
        
        required = llm.invoke(analyze_prompt)
        
        return required
    
    # 特点：
    # - 能力多样（做多件事）
    # - 覆盖广（满足多种需求）
    # - 每个能力不如专精Agent强
    # - 成本中等
    
    # 应用场景：
    # - 个人助手（多种日常任务）
    # - 客服Agent（多种服务）
    # - 多功能助手


# 全能型Agent（General Agent）
class GeneralAgent:
    """全能型Agent - 能做几乎所有事"""
    
    def __init__(self):
        self.base_capabilities = ["reasoning", "planning", "learning"]
        self.tool_access = ToolRegistry()  # 可访问所有工具
    
    def process(self, request):
        """处理任意请求"""
        # 1. 理解请求
        understanding = self.understand_request(request)
        
        # 2. 规划解决方案
        solution_plan = self.plan_solution(understanding)
        
        # 3. 选择工具
        tools = self.select_tools(solution_plan)
        
        # 4. 执行方案
        result = self.execute_solution(solution_plan, tools)
        
        # 5. 生成响应
        response = self.generate_response(result)
        
        return response
    
    def plan_solution(self, understanding):
        """规划解决方案"""
        # 动态规划（不预定义）
        
        plan_prompt = f"""
        理解：{understanding}
        可用工具：{self.tool_access.list()}
        
        规划解决方案：
        1. 问题分析
        2. 解决方案设计
        3. 工具选择
        4. 执行步骤
        
        输出完整方案：
        """
        
        plan = llm.invoke(plan_prompt)
        
        return plan
    
    # 特点：
    # - 能力广泛（几乎能做任何事）
    # - 自适应（根据需求动态调整）
    # - 依赖推理能力（核心）
    # - 成本高（复杂）
    
    # 应用场景：
    # - AI助手（ChatGPT、Claude）
    # - 复杂问题求解
    # - 研究助手
```

---

#### 3. 按协作模式分类

```python
# 独立Agent（Stand-alone Agent）
class StandAloneAgent:
    """独立Agent - 单独工作"""
    
    def __init__(self):
        self.capabilities = ["all_needed_capabilities"]
    
    def work(self, task):
        """独立完成任务"""
        # 不依赖其他Agent
        
        # 1. 理解任务
        understanding = self.understand(task)
        
        # 2. 规划执行
        plan = self.plan(understanding)
        
        # 3. 执行任务
        result = self.execute(plan)
        
        # 4. 返回结果
        return result
    
    # 特点：
    # - 独立性强（不依赖他人）
    # - 响应快（无协调开销）
    # - 能力需全面（自己搞定一切）
    # - 无协作能力
    
    # 应用场景：
    # - 个人AI助手
    # - 单机版智能系统
    # - 简单任务处理


# 协作Agent（Collaborative Agent）
class CollaborativeAgent:
    """协作Agent - 与其他Agent合作"""
    
    def __init__(self):
        self.role = "expert_weather"  # 自己的角色
        self.team = AgentTeam()       # Agent团队
    
    def work(self, task):
        """协作完成任务"""
        # 与其他Agent合作
        
        # 1. 分析任务
        analysis = self.analyze_task(task)
        
        # 2. 确定自己的职责
        my_part = self.determine_my_part(analysis)
        
        # 3. 执行自己的部分
        my_result = self.execute_my_part(my_part)
        
        # 4. 与其他Agent协调
        if analysis["need_collaboration"]:
            # 调用其他Agent
            other_results = self.collaborate_with_others(analysis)
            
            # 合成结果
            final_result = self.synthesize_results(my_result, other_results)
        
        else:
            final_result = my_result
        
        return final_result
    
    def collaborate_with_others(self, analysis):
        """与其他Agent协作"""
        # 调用其他Agent
        
        collaboration_plan = analysis["collaboration_plan"]
        
        results = {}
        
        for agent_role, task_part in collaboration_plan.items():
            if agent_role != self.role:
                # 调用其他Agent
                agent = self.team.get_agent(agent_role)
                
                results[agent_role] = agent.work(task_part)
        
        return results
    
    # 特点：
    # - 专业化（只做擅长的部分）
    # - 协作能力强（能与他人合作）
    # - 能处理复杂任务（团队协作）
    # - 需协调机制
    
    # 应用场景：
    # - Agent团队（CrewAI、AutoGen）
    # - 复杂问题求解（专家协作）
    # - 大型项目


# 竞争Agent（Competitive Agent）
class CompetitiveAgent:
    """竞争Agent - 与其他Agent竞争"""
    
    def __init__(self):
        self.strategy = CompetitionStrategy()
        self.competitors = []
    
    def work(self, task):
        """竞争完成任务"""
        # 与其他Agent竞争最优方案
        
        # 1. 自己提出方案
        my_proposal = self.propose_solution(task)
        
        # 2. 获取其他Agent方案
        other_proposals = self.get_competitor_proposals(task)
        
        # 3. 方案对比竞争
        best_solution = self.compete_for_best(
            my_proposal, 
            other_proposals
        )
        
        # 4. 执行最优方案
        result = self.execute_solution(best_solution)
        
        return result
    
    def compete_for_best(self, proposals):
        """竞争选最优"""
        # 所有方案竞争
        
        # 评估每个方案
        evaluations = []
        
        for proposal in proposals:
            score = self.evaluate_proposal(proposal)
            
            evaluations.append({
                "proposal": proposal,
                "score": score
            })
        
        # 选最优
        best = max(evaluations, key=lambda x: x["score"])
        
        return best["proposal"]
    
    # 特点：
    # - 竞争性强（要赢过其他Agent）
    # - 方案多样（多个Agent方案）
    # - 质量高（竞争选最优）
    # - 成本高（多个Agent都工作）
    
    # 应用场景：
    # - 方案优选（多个方案竞争）
    # - 创意生成（多个Agent创意竞争）
    # - 投资决策（多个策略竞争）
```

---

#### 4. 综合分类对比表

| Agent类型 | 特点 | 优点 | 缺点 | 应用场景 |
|-----------|------|------|------|----------|
| 反应式Agent | 直接响应 | 快速 | 无规划 | 简单触发、传感器 |
| 主动式Agent | 规划后行动 | 智能 | 较慢 | 复杂任务、机器人 |
| 混合式Agent | 反应+规划 | 兼顾速度质量 | 复杂 | 实用场景 |
| 单能力Agent | 专注一事 | 专业高质量 | 能力有限 | 专项助手 |
| 多能力Agent | 多种能力 | 覆盖广 | 不够专精 | 个人助手 |
| 全能型Agent | 能做任何事 | 广泛适应 | 成本高 | AI助手 |
| 独立Agent | 单独工作 | 简单快速 | 能力需全面 | 单机系统 |
| 协作Agent | 团队合作 | 能处理复杂 | 需协调 | Agent团队 |
| 竞争Agent | 方案竞争 | 质量高 | 成本高 | 方案优选 |

### 白话版答案

Agent有三种分类方式：**自主性、能力、协作模式**。

---

**1. 按自主性分类**

```
反应式Agent（Reactive）：
特点：不思考，直接响应
例子：看到下雨 → 直接提醒带伞
优点：快
缺点：无法处理复杂情况
应用：简单客服、智能家居、游戏NPC

主动式Agent（Deliberative）：
特点：先规划，再行动
例子：看到下雨 → 思考 → 规划方案 → 执行
优点：能处理复杂情况
缺点：慢（要规划）
应用：复杂客服、项目助手、机器人导航

混合式Agent（Hybrid）：
特点：紧急快速反应，复杂深度规划
例子：紧急报警 → 快速响应；复杂任务 → 规划后执行
优点：兼顾速度和质量
缺点：系统复杂
应用：智能客服、个人助手（最实用）
```

---

**2. 按能力分类**

```
单能力Agent：
特点：只擅长一件事
例子：天气Agent只能查天气
优点：专精、质量高
缺点：其他事不能做
应用：专项助手（翻译Agent、计算Agent）

多能力Agent：
特点：能做多件事
例子：天气+翻译+计算+搜索
优点：覆盖广、满足多种需求
缺点：每个能力不如专精Agent强
应用：个人助手、客服Agent

全能型Agent：
特点：能做几乎任何事
例子：ChatGPT、Claude
优点：广泛适应、动态调整
缺点：成本高、复杂
应用：AI助手、复杂问题求解
```

---

**3. 按协作模式分类**

```
独立Agent：
特点：单独工作，不依赖其他Agent
例子：个人AI助手单机版
优点：简单、快速
缺点：能力需全面（自己搞定一切）
应用：个人AI助手、单机智能系统

协作Agent：
特点：与其他Agent合作
例子：专家团队（天气Agent+翻译Agent+...)
优点：能处理复杂任务（团队协作）
缺点：需协调机制
应用：Agent团队（CrewAI、AutoGen）

竞争Agent：
特点：与其他Agent竞争最优方案
例子：多个Agent提方案 → 选最优
优点：质量高（竞争选最优）
缺点：成本高（多个Agent都工作）
应用：方案优选、创意生成、投资决策
```

---

**一句话总结**：
Agent分类 = 自主性（反应/主动/混合）+ 能力（单能力/多能力/全能）+ 协作（独立/协作/竞争）