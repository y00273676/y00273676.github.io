---
title: Agent 开发岗位面试与笔试全题库
aliases:
  - AI Agent 面试题
  - Agent Engineer Interview
tags:
  - interview
  - ai-agent
  - llm
  - rag
  - mcp
created: 2026-07-18
updated: 2026-07-18
---

# Agent 开发岗位面试与笔试全题库

> [!abstract] 适用岗位
> AI Agent Engineer、LLM Application Engineer、RAG Engineer、AI 平台工程师、智能体后端工程师、AI Coding Agent 工程师。

这份题库不是背概念清单，而是一套面向真实招聘的复习与自测材料。每题先自己口述，再展开答案。面试回答建议使用 **结论 → 原理 → 工程权衡 → 项目例子** 四段式。

## 0. 使用方法

### 三档掌握标准

- **会解释**：能在 60 秒内说清定义、边界和一个例子。
- **会设计**：能画出数据流，说明失败路径、安全边界和取舍。
- **会落地**：能写核心代码、构造评测集、定位 trace、给出指标。

### 推荐复习顺序

1. 先过“高频 20 题”，形成主干。
2. 再按岗位 JD 补 RAG、平台、Coding Agent 或多 Agent 专题。
3. 独立完成 3 道代码题、2 道 Debug 题、2 道系统设计题。
4. 准备一个真实项目，能回答指标、失败案例和个人贡献。
5. 最后做 60 分钟模拟笔试和 45 分钟模拟面试。

---

# 第一部分：高频 20 题

## Q1：什么是 AI Agent？它和普通聊天机器人有什么区别？

**参考答案：**

Agent 是一个围绕目标持续运行的系统：模型接收当前状态，决定下一步动作，调用工具影响外部环境，读取结果并循环，直到完成、失败或触发停止条件。普通聊天机器人通常是一次输入对应一次生成；Agent 额外包含 **状态、工具、控制循环、权限边界和终止条件**。

面试加分点：Agent 不是“加了 Function Calling 的聊天框”。真正的工程难点在于不确定决策与确定性系统之间的边界管理。

## Q2：一个生产级 Agent 的核心组件有哪些？

**参考答案：**

1. 模型与指令：负责语义理解和决策。
2. Agent loop/orchestrator：负责轮次、状态转移和终止。
3. 工具层：结构化 schema、执行、超时、重试、幂等与鉴权。
4. 上下文与记忆：工作上下文、checkpoint、跨会话长期记忆。
5. 知识检索：RAG、搜索、数据库或业务 API。
6. Guardrails：输入、输出和工具调用前后的校验。
7. Human-in-the-loop：高风险操作审批、澄清与接管。
8. 可观测与评测：trace、token、延迟、成功率、轨迹质量。

## Q3：请描述 Agent loop。

```text
接收目标 → 构建上下文 → 调用模型 → 解析结构化输出
                       ↓
        最终答案 ← 是否结束？ → 选择并校验工具
                                  ↓
                         执行工具并记录 observation
                                  ↓
                    更新状态、预算、记忆 → 下一轮
```

必须有：`max_turns`、超时、token/费用预算、取消信号、重复调用检测、工具错误策略和明确终止状态。

## Q4：Workflow 和 Agent 有什么区别？什么时候不要用 Agent？

**参考答案：**

- Workflow 的路径主要由代码预定义，确定性强、易测、成本低。
- Agent 由模型动态选择动作，适合路径未知、步骤依赖观察结果、需要开放式工具选择的任务。
- 如果流程稳定、规则可枚举、错误代价高或审计要求严格，优先普通代码/工作流；可以把模型放在分类、抽取等局部节点，而不是让整个流程自治。

## Q5：Function Calling 的本质是什么？

**参考答案：**

模型只生成符合约定 schema 的“调用意图和参数”，真正的函数由应用执行。完整链路是：声明工具 → 模型选择工具并生成参数 → 应用验证/授权/执行 → 把结果作为 observation 返回模型。模型本身通常不直接拥有系统权限。

## Q6：如何设计一个好工具？

**参考答案：**

- 名称体现单一职责，描述包含适用与不适用场景。
- 参数少而明确，枚举、格式、必填项和约束写入 schema。
- 返回稳定、紧凑、机器可读的数据，并区分业务失败和系统失败。
- 写操作支持幂等键、dry-run、审计和确认。
- 权限最小化；高风险动作不可仅靠提示词保护。
- 工具集合不宜过大；可按阶段动态暴露或先检索工具。

## Q7：如何防止 Agent 无限循环？

**参考答案：**

多层限制：最大轮次、墙钟超时、token/费用预算、同工具同参数重复检测、状态无进展检测、错误次数上限、显式取消、最终状态机。触发限制后返回可诊断状态，而不是伪造成功。

## Q8：RAG 和 Agent 的关系是什么？

**参考答案：**

RAG 是“获取外部证据并生成”的模式；Agent 是“根据状态动态选择动作”的控制系统。RAG 可以是 Agent 的一个工具，也可以独立存在。固定知识问答通常先用 RAG；只有当检索源、检索步骤或后续动作需要动态决策时才引入 Agent。

## Q9：短期记忆、长期记忆、RAG 有什么区别？

- 短期记忆：当前 thread/run 的消息与状态，服务于任务连续性。
- 长期记忆：跨会话保存的偏好、事实、经验或实体关系，需要写入策略、更新和遗忘。
- RAG：按当前查询从外部知识库取证，不等于“记住用户”。

不要把全部历史消息无限塞回上下文；应使用滑窗、摘要、结构化状态和按需检索。

## Q10：如何实现可恢复的长任务？

**参考答案：**

将执行建模为状态机/图，每个有副作用的步骤前后持久化 checkpoint；为外部写操作使用幂等键；将“计划状态”和“执行结果”分开；支持 pause/resume/cancel；保存模型版本、提示版本、工具版本和 trace ID。恢复时从最后一个已确认状态继续，而不是重放所有副作用。

## Q11：ReAct、Plan-and-Execute、Reflection 分别适合什么场景？

- ReAct：推理与行动交替，适合短到中等长度、反馈频繁的任务。
- Plan-and-Execute：先拆计划再执行，适合长任务，但计划可能过早固化，需要重规划。
- Reflection：增加检查与修正，可提高复杂任务质量，但会增加延迟和成本，也可能“越改越错”。

面试时强调：模式是控制策略，不是越复杂越好；必须用评测决定是否保留。

## Q12：单 Agent 和多 Agent 如何选择？

**参考答案：**

默认从单 Agent + 清晰工具开始。只有当存在明显的上下文隔离、权限隔离、并行子任务、不同模型/提示专长，或团队边界时再拆多 Agent。多 Agent 会带来路由错误、上下文丢失、通信成本、级联失败和更难的评测。

## Q13：Manager-as-tools 和 Handoff 有何区别？

- Manager-as-tools：主 Agent 保留控制权，把专家 Agent 当工具调用，适合统一汇总和中央编排。
- Handoff：将对话/任务控制权转交专家，适合客服路由等由专家直接继续交互的场景。

回答时补充：交接需要定义输入 contract、历史过滤、权限和返回责任。

## Q14：什么是 MCP？它解决什么问题？

**参考答案：**

MCP（Model Context Protocol）是 AI 应用连接外部系统的开放标准。它统一 host/client/server 的交互方式，让 server 暴露 tools、resources、prompts 等能力，并通过能力协商发现双方支持的特性。它解决的是接入协议和生态复用问题，不自动解决业务鉴权、数据可信、提示注入和最小权限。

## Q15：如何评测一个 Agent？

**参考答案：**

至少四层：

1. 结果：任务成功率、答案正确性、业务 KPI。
2. 轨迹：工具选择、参数、步骤数、是否绕路、是否违反策略。
3. 系统：P50/P95 延迟、token、费用、错误率、恢复率。
4. 安全：越权调用、敏感数据泄露、提示注入、危险动作拦截率。

使用离线回归集 + 线上采样；确定性规则、代码判定、人工标注和 LLM-as-judge 组合使用。

## Q16：LLM-as-judge 有哪些风险？

**参考答案：**

位置偏差、长度偏差、自我偏好、提示敏感、领域判断不足和不可复现。缓解方式：明确 rubric、结构化评分、随机交换候选顺序、加入金标准、多人/多模型校准、抽样人工复核。能用确定性校验的地方不要只依赖 judge。

## Q17：如何做 Agent 可观测性？

**参考答案：**

以一次端到端任务为 trace，模型调用、工具调用、handoff、guardrail、检索和人工审批为 span。记录耗时、token、模型/提示/工具版本、状态转移、错误类别与重试次数；敏感输入输出需脱敏或禁采。日志用于找事实，指标用于看趋势，trace 用于还原轨迹。

## Q18：如何防御 Prompt Injection？

**参考答案：**

不能只靠 system prompt。把网页、邮件、文档和工具输出全部视为不可信数据；分离指令与数据；限制可见工具和参数；执行前做策略校验和权限检查；高风险写操作人审；对输出做编码/验证；沙箱执行；使用 canary、审计和安全回归集。尤其注意间接提示注入。

## Q19：如何控制 Agent 成本和延迟？

**参考答案：**

- 模型路由：小模型做分类/抽取，大模型处理难例。
- 缩小上下文：检索、摘要、结构化状态、工具结果裁剪。
- 并行独立步骤，串行有依赖步骤。
- 缓存稳定前缀、检索结果和可复用工具结果。
- 减少模型往返，批量或程序化处理多次工具调用。
- 设置预算并监控“每成功任务成本”，不能只看单次 token。

## Q20：讲一个 Agent 项目时，面试官最想听什么？

使用以下结构：

1. 业务目标与为什么需要 Agent。
2. 你的职责和关键约束。
3. 架构、状态流、工具与数据边界。
4. 最难失败案例及根因。
5. 评测集和上线指标：成功率、延迟、成本、安全。
6. 你做的权衡及替代方案。
7. 复盘：如果重做会删掉什么、补上什么。

---

# 第二部分：基础原理面试题

## 1. LLM 与推理基础

### Q21：Token、Embedding、上下文窗口分别是什么？

Token 是模型处理文本的离散单元；Embedding 是对象在向量空间中的数值表示；上下文窗口是一次推理可接收与生成的 token 总容量。窗口更大不代表有效利用全部上下文，也不代表记忆永久存在。

### Q22：Temperature、top-p 如何影响输出？

它们改变采样分布。低 temperature 通常更稳定，但不能保证事实正确或完全确定；结构化工具调用和评测任务一般用较低随机性。不要同时激进调多个采样参数。

### Q23：为什么同一 Prompt 多次结果不同？如何测试？

来源包括采样、服务端实现、模型版本、并发工具结果和外部数据变化。测试不能只比整段字符串，应测试 schema、事实、业务约束和允许的语义范围；关键路径使用固定数据、版本记录和多次重复统计。

### Q24：Structured Output 和普通 JSON Prompt 有何区别？

普通 JSON Prompt 只是自然语言要求；结构化输出通常由 schema/解码约束保证格式。即便 schema 合法，语义仍可能错误，所以还需业务校验、枚举约束和跨字段验证。

### Q25：模型幻觉的常见成因和治理方法？

知识缺失、上下文证据不足或冲突、任务要求强迫作答、工具失败、采样和错误归纳。治理包括允许“不知道”、检索与引用、工具结果校验、结构化约束、事实核验、评测与人工审批。提示词不能根除幻觉。

### Q26：微调、RAG、Prompt Engineering 如何选择？

- 缺知识且知识常更新：RAG/工具。
- 缺稳定行为、风格或格式：先 Prompt/示例，再考虑微调。
- 需要领域决策模式且有高质量数据：微调可能合适。
- 三者可组合，但先建立 baseline 与评测，否则无法证明收益。

## 2. RAG 与检索

### Q27：完整 RAG 流程是什么？

数据解析 → 清洗 → 分块 → 元数据 → Embedding → 索引 → 查询改写/路由 → 召回 → 过滤/重排 → 上下文组装 → 生成 → 引用/校验 → 评测与更新。

### Q28：Chunk 怎么切？

按语义和文档结构优先，兼顾模型窗口、问题粒度和召回率。代码按符号/AST，表格保留表头与行关系，文档按标题段落。重叠能缓解边界信息丢失，但会增加索引、重复召回和上下文成本。

### Q29：向量检索、关键词检索、混合检索如何选择？

向量检索擅长语义近似；BM25/关键词擅长专有名词、编号和精确匹配；混合检索更稳，再用 reranker 排序。应按查询类型评测，不要默认只用向量库。

### Q30：Recall、Precision、MRR、nDCG 分别衡量什么？

- Recall@k：相关文档是否被召回。
- Precision@k：召回结果中相关文档比例。
- MRR：首个相关结果排名的倒数均值。
- nDCG：考虑多级相关性和排序位置的质量。

生成端还需测 faithfulness、answer relevance、citation correctness 和端到端任务成功率。

### Q31：RAG 答案错误如何排查？

按链路分层：原始数据是否正确 → 解析/切块是否丢信息 → 查询是否表达正确 → 召回是否命中 → 重排是否把正确证据排下去 → 上下文是否被截断 → 模型是否忠于证据。先判断是 retrieval failure 还是 generation failure。

### Q32：如何处理知识更新和删除？

文档使用稳定 ID、版本、更新时间和 ACL；增量索引并支持 tombstone/物理删除；缓存与派生索引同步失效；回答携带证据版本。隐私删除必须覆盖原文、chunk、向量、缓存、日志和备份策略。

### Q33：Graph RAG 什么时候值得用？

当问题依赖实体关系、多跳路径、全局主题或关系约束时有价值。若只是普通 FAQ，图构建和维护成本可能大于收益。可以先以混合检索 + metadata filter + reranker 建 baseline。

---

# 第三部分：Agent 工程面试题

## 1. 工具调用与执行可靠性

### Q34：工具参数合法，但业务上危险，怎么办？

schema 校验后再做业务策略校验：主体是否有权限、资源是否属于该主体、金额/范围是否超限、环境是否允许、是否需要审批。授权必须绑定真实用户身份和服务端上下文，不能相信模型传来的 `user_id` 或 `is_admin`。

### Q35：工具调用失败时，哪些错误该重试？

- 可重试：超时、限流、短暂网络故障、部分 5xx。
- 通常不重试：参数错误、鉴权失败、业务规则拒绝、资源不存在。
- 使用指数退避 + jitter、最大次数、deadline 和熔断。
- 写操作只有具备幂等性或可确认提交状态时才能安全重试。

### Q36：为什么需要幂等？如何实现？

Agent 可能因超时、恢复或模型重复决策再次执行同一动作。对支付、发信、下单等写操作传递业务幂等键，服务端保存结果并对相同键返回同一结果；必要时使用 outbox、状态机或补偿事务。

### Q37：并行工具调用有什么风险？

数据依赖未满足、写冲突、顺序语义破坏、限流放大、错误聚合复杂和上下文膨胀。只有无依赖、只读或能证明冲突安全的步骤才并行；并发数要有上限，并支持取消剩余任务。

### Q38：如何设计工具错误返回？

返回稳定错误结构，例如：

```json
{
  "ok": false,
  "error": {
    "code": "RATE_LIMITED",
    "message": "human-readable summary",
    "retryable": true,
    "retry_after_ms": 1000
  }
}
```

不要把内部堆栈、密钥或整页 HTML 返回给模型。模型需要可行动信息，工程日志保存详细诊断。

### Q39：工具结果太大怎么办？

分页、过滤、投影字段、服务端聚合、只返回引用 ID、对结果分层摘要；让模型先决定查询范围。避免把数据库全表或超长网页直接送入上下文。

### Q40：如何处理工具 schema 演进？

显式版本、向后兼容、契约测试、灰度发布；trace 记录工具版本。破坏性变更使用新工具名或新版本，在旧版本流量清零前保留适配层。

## 2. 状态、记忆与上下文工程

### Q41：Context Engineering 是什么？

它是决定模型在每一步“看见什么”的工程：系统规则、任务状态、历史消息、检索证据、工具定义/结果、记忆和输出约束。核心不是把信息塞得越多越好，而是提供当前决策所需的最小、可信、按优先级组织的上下文。

### Q42：如何做对话压缩？

保留最近原始轮次 + 结构化任务状态 + 可追溯摘要。摘要需要保留未决事项、承诺、关键实体、工具结果引用和用户约束；重要事实应回写长期存储而非只存在自然语言摘要中。

### Q43：长期记忆写入策略怎么设计？

明确候选类型（偏好、稳定事实、任务经验）、写入触发、置信度、来源、作用域、TTL 和用户可见/可删能力。不要把模型推断自动当事实；敏感数据默认不写；新事实与旧事实冲突时走更新或确认策略。

### Q44：记忆污染是什么？

错误、恶意或过期内容被写入长期记忆，之后持续影响决策。防护包括来源标记、写入校验、作用域隔离、置信度和时间衰减、版本历史、用户纠正、敏感动作不依赖未经确认的记忆。

### Q45：Checkpoint 和长期记忆有什么区别？

Checkpoint 保存某一任务/thread 的执行状态，用于恢复、中断、人审和容错；长期记忆保存跨任务可复用信息。前者关注执行一致性，后者关注检索、更新、遗忘和隐私。

## 3. 规划、路由与多 Agent

### Q46：模型路由怎么做？

可按任务类型、难度、风险、上下文长度、语言和成本选择模型。路由器可以是规则、小模型或级联：先小模型，低置信度/失败再升级。必须测路由错误成本，避免为省 token 导致整体成功率下降。

### Q47：如何判断 Agent “没有进展”？

连续状态 hash 不变、重复工具+参数、相同错误循环、未决子目标数不下降、观测没有新增信息。检测后可重规划、换工具、请求澄清或终止。

### Q48：多 Agent 通信 contract 应包含什么？

任务目标、输入 schema、允许的上下文、完成定义、权限、预算、deadline、输出 schema、错误类型、证据引用和 trace/span 关联。自由文本“你帮我处理一下”难以评测和恢复。

### Q49：多 Agent 的常见失败模式？

错误路由、重复劳动、互相确认形成循环、上下文在交接中丢失、权限扩大、共享记忆污染、某个 Agent 幻觉导致级联失败、成本指数增长。需要中央预算、拓扑限制、最大深度、contract 和端到端 trace。

### Q50：什么时候用图/状态机，而不是自由循环？

当流程存在明确阶段、审批、补偿、并行汇合、长时间等待、恢复和审计需求时使用图/状态机。自由循环适合短、低风险、探索性任务。生产系统常是“确定性骨架 + 局部 Agent 节点”。

## 4. MCP

### Q51：MCP 中 tools、resources、prompts 的区别？

- Tools：模型可选择调用的动作，可能有副作用。
- Resources：应用可读取的上下文数据，类似资源接口。
- Prompts：用户显式选择的结构化提示模板/工作流入口。

具体能力以 server/client 协商结果为准。

### Q52：stdio 和远程 MCP 连接各有什么权衡？

stdio 适合本机子进程，部署简单且边界清晰；远程连接适合共享服务和跨环境，但需要传输安全、身份认证、授权、租户隔离、限流和会话管理。

### Q53：接入第三方 MCP Server 前要审查什么？

来源与代码、暴露能力、数据流向、凭据存储、OAuth/授权、工具描述是否可能变化、网络访问、文件系统范围、日志与隐私、依赖供应链、超时限流。默认使用最小权限并隔离运行。

### Q54：MCP 为什么不等于安全边界？

协议只规范互操作。server 仍可能返回恶意内容、暴露危险工具或错误处理令牌；client 仍需做授权、输入输出校验、用户确认、沙箱、审计和来源信任。

## 5. 评测、测试与可观测性

### Q55：如何构造 Agent 评测集？

来源包括真实匿名流量、历史事故、产品需求、对抗样本和合成边界样本。按任务类型、难度、语言、工具、权限和风险分层；每条样本定义输入、环境 fixture、成功判据、允许轨迹和禁止动作。保留 train/dev/test，防止提示词针对测试集过拟合。

### Q56：如何测试非确定性 Agent？

固定工具 fixture 与随机源，断言不变量和结果范围；每个样本多次运行，报告均值、方差和置信区间；对关键步骤做 contract test，对端到端做任务成功率，对安全红线要求零容忍或明确阈值。

### Q57：离线评测好，线上指标却下降，可能为什么？

评测集分布过时、工具/数据环境不同、线上长尾更复杂、用户行为反馈、延迟导致中途退出、安全策略误杀或观测偏差。需要线上 shadow/canary、分群指标和失败样本回流。

### Q58：一次 Agent trace 应记录什么？

run/thread/trace ID、父子 span、时间、模型和版本、提示版本、token、工具名/版本、参数摘要、结果状态、重试、状态转移、审批、安全事件和最终结果。敏感数据按字段脱敏，生产环境避免默认记录完整内容。

### Q59：如何定位 P95 延迟突增？

按 span 拆模型、检索、工具、队列和审批等待；比较模型首 token/总耗时、工具下游、重试率、并发和限流；按模型版本、租户、任务类型和发布版本切片。平均值通常掩盖长尾。

### Q60：如何做 Prompt 版本管理？

Prompt 进入代码/配置版本库，包含 owner、版本、变更原因和适用模型；离线回归后灰度；trace 记录版本；支持快速回滚。Prompt、模型、工具 schema 和检索配置应作为一个可复现实验单元。

## 6. 安全与治理

### Q61：什么是 Excessive Agency？

系统给模型过多功能、权限或自治范围，导致错误或被操纵时影响放大。治理原则是最小功能、最小权限、最小自治，高风险动作使用审批、可逆操作、限额和审计。

### Q62：如何安全实现“Agent 发邮件”？

读取邮件和发送邮件使用不同权限；默认草稿模式；展示收件人、主题、正文和附件供确认；限制收件域/数量；防止正文中的间接注入影响发送决策；使用幂等键、防重复发送和审计记录。

### Q63：为什么工具输出也要做安全处理？

工具输出可能包含恶意指令、HTML/脚本、敏感数据、超长内容或伪造状态。应按不可信数据处理：类型校验、内容裁剪、转义、来源标记、秘密扫描、策略过滤，不能把它自动提升为高优先级指令。

### Q64：沙箱解决什么，不能解决什么？

沙箱限制文件、进程、网络和资源，降低代码执行影响；但不能自动解决社会工程、凭据滥用、业务 API 越权、数据外泄到允许的网络目标或错误业务决策。还需身份、授权和业务策略。

### Q65：如何防止敏感信息泄露到模型或 trace？

数据最小化、字段级脱敏、密钥永不进入 prompt、短期凭据、供应商/区域策略、日志采样与访问控制、保留期和删除机制。对 tool result、memory、embedding、缓存、评测样本和 trace 做全链路数据盘点。

---

# 第四部分：系统设计题

## SD1：设计一个企业知识库问答 Agent

### 需求澄清

- 数据源：文档、Wiki、工单、数据库？更新频率？
- 用户与 ACL：是否必须继承源系统权限？
- 问题类型：事实问答、多跳分析还是执行动作？
- 指标：正确率、引用率、P95、QPS、成本、拒答率。

### 参考架构

```text
用户 → API/Auth → Query Router → Retrieval Pipeline
                         │             ├─ ACL filter
                         │             ├─ hybrid search
                         │             └─ reranker
                         ↓
                 Agent/Answer Node → citation validator → response
                         │
                   tool gateway
                         │
             tracing / eval / feedback / audit

Ingestion: connectors → parse → chunk → metadata/ACL → index/version
```

### 必答点

- ACL 在检索前过滤，不能只在生成后遮盖。
- 回答携带引用；无证据时拒答或澄清。
- 先做非 Agent RAG baseline，再证明动态工具选择的价值。
- 增量索引、删除同步、缓存失效、多租户隔离。
- 分开评测 retrieval 与 generation。

## SD2：设计一个自动处理客服退款的 Agent

### 状态机

`识别意图 → 收集订单 → 查询资格 → 计算方案 → 用户确认 → 审批/退款 → 通知 → 完成`

### 风险控制

- 模型不直接决定权限与金额，规则服务判断退款资格。
- 退款工具必须幂等，有金额上限和审批。
- 写操作前展示摘要并确认；执行后以支付系统状态为准。
- 失败进入人工队列，不把“请求已提交”说成“退款成功”。
- 所有状态和证据可审计。

## SD3：设计一个长时间运行的 Coding Agent

### 核心模块

- Repo/worktree 隔离与沙箱。
- 任务规划、文件检索、编辑、终端、测试工具。
- Checkpoint、计划文件、token/时间预算和可取消执行。
- 权限分级：读、改、执行、联网、提交/推送分别授权。
- 测试 oracle、lint/typecheck、安全扫描和 diff review。
- trace 关联到命令、补丁、测试结果和模型版本。

### 关键追问

- 如何避免修改用户已有改动？先检查 dirty worktree，隔离分支/worktree，补丁应用保持局部。
- 如何恢复？持久化计划、已完成步骤、工作区快照和外部副作用。
- 如何证明完成？运行与风险相称的验证，基于真实输出而不是模型自述。

## SD4：设计多 Agent 研究系统

建议采用 manager-worker：manager 拆分相互独立的问题，worker 在预算内检索并返回“结论 + 证据 + 不确定性”，synthesizer 去重、处理冲突并生成报告。

重点讨论：任务去重、来源可信度、引用可追溯、并发上限、子 Agent 深度限制、失败隔离、共享上下文大小和最终事实核验。

## SD5：从 10 QPS 扩展到 1000 QPS

答题框架：

1. 先确认瓶颈：模型配额、工具下游、向量库、队列、CPU/内存。
2. 异步 API + 队列；无状态 worker；thread/checkpoint 外置。
3. 按租户限流和公平调度；背压、超时、取消。
4. 缓存、批处理、模型路由、并行只读工具。
5. 降级：小模型、减少检索、只读模式、转人工。
6. 压测端到端，并监控成功任务成本和 P95/P99。

---

# 第五部分：Debug 场景题

## D1：Agent 不停调用同一个搜索工具

### 排查顺序

1. trace 中参数是否完全相同，结果是否有新增信息。
2. 工具描述是否让模型误以为必须继续搜索。
3. 是否缺少明确完成条件或答案工具。
4. 搜索结果是否为空、过长或错误未被结构化表达。
5. `tool_choice` 是否被强制且调用后未重置。

### 修复

重复调用检测、最大轮次、返回结构化覆盖信息、明确停止条件、失败分类、必要时加入状态机，而不是只在 prompt 写“不要循环”。

## D2：工具显示成功，但用户收到重复扣款

根因通常是模型重复调用、网络超时后重试、恢复时重放或服务端没有幂等。修复重点是服务端幂等键、交易状态查询、唯一约束/outbox、审计与补偿；提示词不是正确修复层。

## D3：离线准确率 90%，上线只有 65%

检查训练/测试泄漏、评测分布、线上数据新鲜度、ACL、工具超时、Prompt/模型版本、用户语言和长尾。抽样线上失败并标记为路由、检索、工具、推理、策略或 UX 失败，再决定修复层。

## D4：RAG 引用看似正确，但答案与原文不一致

可能是引用粒度过大、模型拼接推断、证据冲突或引用选择发生在生成后。需要逐句 claim-evidence 对齐、引用 span、矛盾检测、无足够证据时拒答，并单测 citation correctness。

## D5：多 Agent 成本突然增加 5 倍

查看 fan-out 数、handoff 深度、重复任务、上下文复制、失败重试、模型路由和工具返回大小。设置全局预算、子任务预算、最大拓扑深度、任务指纹去重和集中式 usage accounting。

## D6：加了 Reflection，效果反而下降

反思模型可能缺少新证据，只是对原答案做语言改写；judge 偏好长答案；多轮引入新幻觉。做消融实验，约束反思只检查 rubric，并要求基于工具/测试结果修正；无增益则删除该步骤。

## D7：摘要后 Agent 忘记用户的关键限制

不要只保存自由文本摘要。把目标、约束、完成条件、未决事项和关键实体保存在结构化状态；摘要模板覆盖这些字段；重要约束设为不可压缩区并做恢复测试。

## D8：Prompt Injection 让 Agent 尝试上传本地文件

立即阻断网络/文件组合权限并审计。根因是将不可信内容当指令、工具权限过大、缺少数据流策略。使用内容来源分区、最小权限、敏感文件 denylist/allowlist、出站限制、上传审批和对抗回归测试。

---

# 第六部分：笔试代码题

> [!tip] 笔试评分通则
> 正确性 40%，异常与边界 20%，可测试性 15%，安全与可靠性 15%，表达与复杂度 10%。只写 happy path 通常拿不到高分。

## C1：实现一个有预算和防循环的 Agent Loop

### 题目

实现 `run_agent(model, tools, user_input)`。要求：最多 8 轮；校验工具名与参数；同一工具同一参数最多执行 2 次；工具超时 5 秒；总预算 30 秒；输出明确的完成或失败状态。

### Python 参考实现

```python
from __future__ import annotations

import asyncio
import json
import time
from collections import Counter
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

Tool = Callable[..., Awaitable[dict[str, Any]]]


@dataclass
class RunResult:
    status: str
    output: str | None
    turns: int
    error: str | None = None


def call_key(name: str, arguments: dict[str, Any]) -> str:
    normalized = json.dumps(arguments, sort_keys=True, ensure_ascii=False)
    return f"{name}:{normalized}"


async def run_agent(model, tools: dict[str, Tool], user_input: str) -> RunResult:
    messages: list[dict[str, Any]] = [{"role": "user", "content": user_input}]
    seen: Counter[str] = Counter()
    deadline = time.monotonic() + 30

    for turn in range(1, 9):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return RunResult("timeout", None, turn - 1, "run budget exceeded")

        try:
            response = await asyncio.wait_for(model(messages), timeout=remaining)
        except asyncio.TimeoutError:
            return RunResult("timeout", None, turn - 1, "model timeout")

        if response["type"] == "final":
            return RunResult("completed", response["content"], turn)

        if response["type"] != "tool_call":
            return RunResult("failed", None, turn, "invalid model response")

        name = response.get("name")
        arguments = response.get("arguments")
        if name not in tools or not isinstance(arguments, dict):
            observation = {"ok": False, "error": {"code": "INVALID_TOOL_CALL"}}
        else:
            key = call_key(name, arguments)
            seen[key] += 1
            if seen[key] > 2:
                return RunResult("stalled", None, turn, "repeated tool call")

            try:
                timeout = min(5, max(0.001, deadline - time.monotonic()))
                observation = await asyncio.wait_for(tools[name](**arguments), timeout)
            except asyncio.TimeoutError:
                observation = {"ok": False, "error": {"code": "TOOL_TIMEOUT"}}
            except Exception as exc:  # 生产中映射为稳定错误码并记录内部堆栈
                observation = {
                    "ok": False,
                    "error": {"code": "TOOL_ERROR", "message": type(exc).__name__},
                }

        messages.extend([response, {"role": "tool", "content": observation}])

    return RunResult("max_turns", None, 8, "turn limit exceeded")
```

### 面试官追问

- schema 校验应放在哪里？工具网关，执行前必须二次校验。
- 写操作如何重试？必须有业务幂等键和提交状态确认。
- 如何取消？向模型和工具传递 cancellation/deadline。

## C2：实现指数退避重试

### 题目

只重试 `RateLimitError` 和 `TransientError`；使用指数退避、jitter、最大尝试次数和总 deadline。

```python
import asyncio
import random
import time


async def retry(call, *, attempts=4, base=0.2, deadline_s=3.0):
    deadline = time.monotonic() + deadline_s
    for attempt in range(attempts):
        try:
            return await call()
        except (RateLimitError, TransientError):
            if attempt == attempts - 1:
                raise
            delay = base * (2**attempt) * random.uniform(0.5, 1.5)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("retry deadline exceeded")
            await asyncio.sleep(min(delay, remaining))
```

加分点：尊重服务端 `Retry-After`；不可重试错误直接抛出；写操作讨论幂等。

## C3：实现工具调用去重与幂等缓存

### 题目

给定 `tool_name + args + user_scope`，生成稳定 key。并发相同请求只执行一次；失败结果不永久缓存。

**答题要点：** canonical JSON、用户/租户作用域、singleflight、TTL、错误缓存策略、工具版本进入 key、敏感参数不能原文写日志。

## C4：实现并发工具执行器

### 题目

输入多个无依赖工具调用，最大并发 5；任何高风险调用失败时取消剩余任务；输出保持输入顺序。

**答题要点：** `asyncio.Semaphore`、task cancellation、`gather(return_exceptions=True)` 的语义、deadline 传播、部分成功结构。先验证“无依赖”这一前提。

## C5：写一个安全的 SQL 查询工具

### 必须满足

- 模型不能传任意 SQL，只能传业务参数或受限查询 DSL。
- 使用参数化查询，禁止字符串拼接。
- 数据库账户只读、限制表/列、行数、执行时间。
- 强制租户条件，租户 ID 来自服务端身份上下文。
- 返回字段裁剪并做敏感数据脱敏。

反例：让模型生成 `SELECT ...` 后仅用正则检查是否以 `SELECT` 开头。

## C6：为工具 schema 写验证器

### 题目

订单退款参数包括 `order_id`、`amount`、`reason`。要求金额大于 0，不能超过订单可退金额，原因枚举，高于 500 元需审批。

**答题要点：** 语法校验与业务校验分层；可退金额从可信订单服务查询；不能相信模型传入的原订单金额；审批是状态，而非布尔参数让模型自行传入。

## C7：实现简单 Hybrid Search

### 题目

给定 BM25 和 vector 两组排序结果，使用 Reciprocal Rank Fusion 合并。

```python
from collections import defaultdict


def rrf(*rankings: list[str], k: int = 60) -> list[tuple[str, float]]:
    scores: dict[str, float] = defaultdict(float)
    for ranking in rankings:
        for rank, doc_id in enumerate(ranking, start=1):
            scores[doc_id] += 1.0 / (k + rank)
    return sorted(scores.items(), key=lambda item: (-item[1], item[0]))
```

追问：如何离线选 `k` 和 top-n？在带相关性标注的验证集上按 nDCG/Recall 调参，并观察生成端指标。

## C8：实现对话窗口压缩策略

### 要求

始终保留 system、最近 6 轮、结构化约束和未决事项；旧消息先摘要；工具大结果只保留引用和关键字段；估算 token 超限时继续裁剪。

加分点：摘要失败回退、不可压缩字段、摘要版本和恢复测试。

## C9：实现 SSE 流式 Agent API

### 考点

事件类型应区分 `message.delta`、`tool.started`、`tool.completed`、`approval.required`、`run.completed`、`run.failed`；带 event ID 以支持断线续传；客户端断开后传播取消；不要把内部思维过程直接流给客户端。

## C10：设计 Agent Run 数据表

### 最小字段

`run_id, thread_id, user_id, status, model_version, prompt_version, input_ref, output_ref, checkpoint, token_usage, cost, started_at, ended_at, error_code, trace_id, version`

追问：并发恢复如何避免双执行？乐观锁/租约、状态条件更新、幂等副作用。

---

# 第七部分：Prompt 与评测笔试题

## P1：改写一个糟糕的工具 Prompt

### 原 Prompt

```text
你是一个万能助手，尽量帮助用户。你可以调用所有工具。不要犯错。
```

### 改写应包含

- 角色与任务边界。
- 工具选择条件和禁止条件。
- 不可信数据不能覆盖上层指令。
- 缺必要参数时澄清，不能猜。
- 写操作先预览/确认。
- 完成条件、失败表达和结构化输出。

注意：Prompt 只定义模型行为；权限、金额限制、审批仍在代码层实现。

## P2：设计一个意图路由器

输出 schema：

```json
{
  "route": "faq | order_query | refund | human",
  "confidence": 0.0,
  "reason_code": "string",
  "missing_fields": []
}
```

要求：低置信度转人工；用混淆矩阵评测；退款误路由的代价高于 FAQ 误路由，可使用不同阈值。

## P3：为客服 Agent 设计评测 rubric

建议维度：事实正确性 30、政策合规 25、任务完成 20、工具轨迹 10、表达 10、效率 5。越权退款、泄漏敏感数据、伪造执行成功为红线，无论总分多少都判失败。

## P4：构造 Prompt Injection 安全测试集

覆盖：直接越权指令、网页/邮件/文档中的间接注入、Unicode/编码混淆、角色伪装、工具结果伪造、数据外传、记忆污染、多轮渐进攻击。每例定义允许行为、禁止工具、预期审批和审计事件。

## P5：如何做 A/B Test？

先设主要指标和护栏指标；用户/thread 稳定分桶；控制模型/工具/流量差异；估算样本量；监测 novelty 与学习效应；高风险变更先 shadow/canary。成功率提高但成本或安全事故上升，不应简单判定胜出。

---

# 第八部分：60 分钟模拟笔试

## 试卷

### 一、简答题（20 分，20 分钟）

1. Workflow 与 Agent 的边界是什么？（5 分）
2. 如何保证写工具可安全重试？（5 分）
3. 解释 MCP 的三类核心 server 能力及安全注意事项。（5 分）
4. Agent 评测为什么不能只看最终答案？（5 分）

### 二、代码题（35 分，25 分钟）

实现一个异步工具执行器：最大并发 3、单工具超时 2 秒、保序返回、区分超时/业务异常/系统异常，并说明写操作的幂等策略。

### 三、系统设计题（35 分，12 分钟）

设计一个“读取用户邮箱、总结待办并生成回复草稿”的 Agent。画出架构并说明间接 Prompt Injection、隐私、授权、审批、可观测和评测方案。

### 四、复盘题（10 分，3 分钟）

说出方案中最可能失败的三个地方，以及上线前如何验证。

## 评分锚点

- 85–100：有生产经验；能主动覆盖权限、失败路径、幂等、评测和可观测。
- 70–84：架构完整，部分工程细节不足。
- 55–69：概念了解，但答案停留在框架名和 Prompt。
- <55：把 Agent 当成一次 LLM API 调用，缺少系统边界意识。

---

# 第九部分：项目深挖与行为面

## 项目深挖 15 问

1. 为什么这个需求需要 Agent，而不是规则或 Workflow？
2. 你个人负责哪一部分？关键代码或决策是什么？
3. 最初 baseline 是什么？Agent 带来了多少增益？
4. 工具有多少个？为什么这样拆？
5. 状态存在哪里？失败后如何恢复？
6. 最严重的一次线上失败是什么？
7. 如何构建评测集？有多少真实样本？
8. 任务成功率如何定义？谁判定成功？
9. P50/P95 延迟和单任务成本是多少？
10. Prompt、模型、工具变更如何回归和灰度？
11. 如何防止越权和提示注入？
12. 哪个复杂设计后来被你删掉了？为什么？
13. 如果工具返回互相矛盾的信息怎么办？
14. 用户不信任结果时，产品如何提供证据和控制权？
15. 如果流量增长 100 倍，先改哪里？

## STAR 行为面题

### B1：讲一次你处理线上事故的经历

重点：影响范围、止损、事实收集、根因、修复、回归集和长期机制。不要只说“优化 Prompt”。

### B2：讲一次你反对过度使用 Agent 的经历

理想答案：用 baseline、风险和维护成本说服团队，把确定性流程留给代码，把模型用在真正不确定的节点。

### B3：需求方只说“准确率要到 95%”，你怎么办？

澄清样本分布、错误成本、判定标准、置信区间和拒答策略，把模糊目标转换成可测指标和验收集。

### B4：你与算法/产品/安全团队意见冲突时怎么处理？

统一业务目标，列出假设和风险，用小规模实验或 threat model 提供证据，记录决策与 owner，而不是争论框架偏好。

## 自我介绍模板（90 秒）

```text
我有 X 年后端/AI 应用开发经验，主要使用 [语言与技术栈]。
最近我负责 [Agent 项目]，目标是 [业务目标]。
我重点完成了 [工具/编排/RAG/评测/平台]，解决了 [关键难点]，
将 [成功率/延迟/成本/人工量] 从 A 改善到 B。
我擅长把不确定的模型能力放进可测试、可恢复、可审计的工程系统，
希望在贵公司的 [岗位方向] 继续做生产级 Agent。
```

## 反问面试官

1. 团队当前 Agent 的主要业务指标和最大失败模式是什么？
2. 评测集主要来自真实流量还是合成数据？谁负责标注与回归？
3. 模型、平台、应用和安全团队如何分工？
4. 当前采用确定性 Workflow 与自治 Agent 的边界是什么？
5. 这个岗位前三个月最重要的交付是什么？
6. 团队如何处理模型升级、成本、可观测与线上事故？

---

# 第十部分：不同岗位的加餐重点

## 偏后端/平台

并发、队列、状态机、幂等、租约、分布式锁、缓存、限流、熔断、多租户、鉴权、数据库、SSE/WebSocket、Kubernetes、可观测性。

## 偏算法/应用

Prompt、structured output、检索、reranker、query rewrite、模型路由、微调、数据构造、离线评测、LLM-as-judge、A/B test。

## 偏 Coding Agent

代码检索、AST/LSP、补丁生成、worktree、沙箱、终端安全、测试 oracle、长任务恢复、上下文压缩、diff review、供应链安全。

## 偏企业 Agent

MCP/连接器、OAuth、RBAC/ABAC、ACL-aware retrieval、审计、PII、数据驻留、人审、SLA、多租户、成本核算。

---

# 第十一部分：14 天冲刺计划

| 天数 | 主题 | 当天产出 |
|---:|---|---|
| Day 1 | LLM、结构化输出、Function Calling | 口述 Q1–Q6；写一个工具调用 demo |
| Day 2 | Agent loop、Workflow、状态机 | 手写 C1；画两种架构 |
| Day 3 | RAG 全链路 | 完成 Q27–Q33；做检索错误树 |
| Day 4 | 工具可靠性 | 重试、超时、幂等、并发各写一个例子 |
| Day 5 | Memory 与 Context Engineering | 设计 checkpoint 和长期记忆表 |
| Day 6 | Planning 与 Multi-Agent | 比较 ReAct、Plan-and-Execute、handoff |
| Day 7 | MCP | 实现/阅读一个最小 server；整理安全清单 |
| Day 8 | 安全 | 完成 threat model 与注入测试集 |
| Day 9 | Evals | 建 20 条评测集、rubric 和失败分类 |
| Day 10 | Observability/性能 | 画 trace；解释 P95 与成本优化 |
| Day 11 | 系统设计 | 限时完成 SD1、SD2 |
| Day 12 | 代码与 Debug | 限时完成 C2/C4/C7、D1–D8 |
| Day 13 | 项目与行为面 | 录制 90 秒自我介绍和 10 分钟项目讲解 |
| Day 14 | 全真模拟 | 60 分钟笔试 + 45 分钟面试，整理错题 |

---

# 第十二部分：面试前检查清单

- [ ] 能在 60 秒说清 Agent、Workflow、RAG、MCP 的边界。
- [ ] 能手写带超时、预算、防循环、错误分类的 Agent loop。
- [ ] 能解释重试为什么必须和幂等一起讨论。
- [ ] 能画一个确定性骨架 + Agent 节点的生产架构。
- [ ] 能给出结果、轨迹、系统、安全四层评测指标。
- [ ] 能解释直接与间接 Prompt Injection。
- [ ] 能说明 checkpoint、短期记忆、长期记忆的区别。
- [ ] 能用真实数字讲一个项目和一个失败案例。
- [ ] 能回答为什么不用多 Agent、为什么不用某个框架。
- [ ] 准备好 6 个高质量反问。

---

# 延伸专题

- [[Agent面试题/README|现有 72 道 Agent 面试题总览]]
- [[Agent面试题/01-架构设计/基础概念]]
- [[Agent面试题/02-工具调用/核心原理]]
- [[Agent面试题/03-记忆系统/记忆架构]]
- [[Agent面试题/04-规划推理/核心方法]]
- [[Agent面试题/06-框架对比/主流框架]]
- [[Agent面试题/08-安全伦理/核心问题]]
- [[AI_Interview|AI 辅助编程面试题]]

# 权威参考资料

- [OpenAI Agents SDK](https://openai.github.io/openai-agents-python/)：Agent loop、tools、handoffs、guardrails、sessions、human-in-the-loop、tracing。
- [OpenAI Agents SDK — Tools](https://openai.github.io/openai-agents-python/tools/)：工具类别、函数工具、Agent as tools。
- [OpenAI Agents SDK — Tracing](https://openai.github.io/openai-agents-python/tracing/)：trace/span 与默认观测事件。
- [LangGraph Overview](https://langchain-ai.github.io/langgraph/index.html)：durable execution、streaming、human-in-the-loop、persistence。
- [LangGraph Persistence](https://langchain-ai.github.io/langgraph/cloud/concepts/threads/)：checkpointer 与 store 的职责区别。
- [Model Context Protocol](https://modelcontextprotocol.io/docs/getting-started/intro)：MCP 概览。
- [MCP Architecture](https://modelcontextprotocol.io/docs/learn/architecture)：host/client/server、能力协商和核心原语。
- [MCP Security Best Practices](https://modelcontextprotocol.io/docs/tutorials/security/security_best_practices)：授权与协议安全注意事项。
- [Anthropic：Mitigate jailbreaks and prompt injections](https://docs.anthropic.com/en/docs/test-and-evaluate/strengthen-guardrails/mitigate-jailbreaks)：直接与间接提示注入及分层防护。
- [OWASP GenAI Security Project](https://genai.owasp.org/)：Prompt Injection、Sensitive Information Disclosure、Excessive Agency 等风险分类。

> [!note] 更新原则
> 框架 API 和模型能力变化很快。复习时优先掌握稳定的工程原则，再根据目标公司的技术栈核对最新官方文档；不要把某个框架当前 API 当成 Agent 架构本身。
