# Agent 框架对比 - AutoGen深度解析

## Q35: AutoGen 的对话式协作机制是什么？如何实现人机协作？

### 专业版答案

#### AutoGen 核心概念

**AutoGen**（微软开发）是**对话式多Agent框架**，Agent间通过自然对话协作，人类可以随时介入。

核心理念：**Agent间对话 + 人类监督 + 代码执行**

---

#### 1. Agent类型

```python
import autogen

# Assistant Agent（助手Agent）
assistant = autogen.AssistantAgent(
    name="assistant",
    
    # 系统消息（定义角色）
    system_message="""
    你是一个智能助手，擅长解决问题。
    当遇到复杂问题时，可以：
    1. 写代码解决
    2. 请人类确认
    3. 请求更多信息
    """,
    
    # LLM配置
    llm_config={
        "model": "gpt-4",
        "temperature": 0.7
    }
)

# User Proxy Agent（人类代理）
user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    
    # 人类代理配置
    human_input_mode="ALWAYS",  # ALWAYS/TERMINATE/NEVER
    # ALWAYS：每轮都问人类
    # TERMINATE：结束时问人类
    # NEVER：全自动
    
    # 代码执行配置
    code_execution_config={
        "work_dir": "coding",
        "use_docker": True  # Docker沙箱执行
    },
    
    # 最大对话轮数
    max_consecutive_auto_reply=10
)

# Group Chat（群聊）
group_chat = autogen.GroupChat(
    agents=[assistant, user_proxy],
    messages=[],
    max_round=20
)

# Manager Agent（群聊管理者）
manager = autogen.GroupChatManager(
    groupchat=group_chat,
    llm_config={"model": "gpt-4"}
)
```

---

#### 2. 对话协作机制

```python
# 单Agent对话
user_proxy.initiate_chat(
    assistant,
    message="帮我写一个Python爬虫"
)

# 对话流程：
"""
Round 1:
User Proxy: "帮我写一个Python爬虫"
Assistant: "好的，我先设计爬虫方案...需要确认几个问题：
- 爬取什么网站？
- 爬取什么数据？
- 存储格式？
"
User Proxy（人类）: "爬取新闻网站，爬标题和内容，存JSON"

Round 2:
Assistant: "明白了，我来写代码..."
[Assistant生成代码]
Assistant: "代码已生成，请执行查看效果"
User Proxy: [执行代码]

Round 3:
Assistant: "代码执行成功，生成了数据。需要优化吗？"
User Proxy（人类）: "需要，加个进度条"

Round 4:
Assistant: [修改代码，添加进度条]
Assistant: "已优化，请执行"
User Proxy: [执行代码]

Round 5:
Assistant: "执行成功，任务完成"
User Proxy（人类）: "好的，结束"
"""
```

---

#### 3. 多Agent协作

```python
# 定义多个专家Agent
code_writer = autogen.AssistantAgent(
    name="code_writer",
    system_message="你是代码编写专家，擅长写高质量代码",
    llm_config={"model": "gpt-4"}
)

code_reviewer = autogen.AssistantAgent(
    name="code_reviewer",
    system_message="你是代码审查专家，擅长发现问题和优化代码",
    llm_config={"model": "gpt-4"}
)

code_executor = autogen.UserProxyAgent(
    name="code_executor",
    human_input_mode="NEVER",  # 全自动执行
    code_execution_config={"work_dir": "workspace"}
)

# 群聊协作
group_chat = autogen.GroupChat(
    agents=[code_writer, code_reviewer, code_executor],
    messages=[]
)

manager = autogen.GroupChatManager(
    groupchat=group_chat
)

# 启动协作
code_executor.initiate_chat(
    manager,
    message="开发一个数据分析程序"
)

# 对话流程：
"""
Round 1:
Code Executor: "开发一个数据分析程序"
Manager（分配）: "Code Writer负责编写"
Code Writer: "好的，开始编写..."

Round 2:
Code Writer: [生成代码]
Code Writer: "代码已完成，请审查"
Manager（分配）: "Code Reviewer负责审查"
Code Reviewer: "审查发现3个问题..."

Round 3:
Code Reviewer: "问题列表：..."
Code Writer: [修改代码]
Code Writer: "已修改"

Round 4:
Code Reviewer: "审查通过"
Manager（分配）: "Code Executor负责执行"
Code Executor: [执行代码]

Round 5:
Code Executor: "执行成功"
Manager: "任务完成"
"""
```

---

#### 4. 人类介入机制

```python
# 三种介入模式

# 1. ALWAYS模式（每轮都介入）
user_proxy_always = autogen.UserProxyAgent(
    name="user_proxy_always",
    human_input_mode="ALWAYS",  # 每轮对话都问人类
    # Agent说完话，必须等人类回复
)

# 2. TERMINATE模式（结束时介入）
user_proxy_terminate = autogen.UserProxyAgent(
    name="user_proxy_terminate",
    human_input_mode="TERMINATE",  # Agent完成任务后才问人类
    # 只有任务结束时才问人类确认
)

# 3. NEVER模式（全自动）
user_proxy_never = autogen.UserProxyAgent(
    name="user_proxy_never",
    human_input_mode="NEVER",  # 不问人类，全自动
    # Agent自主执行，但可以限制轮数
    max_consecutive_auto_reply=5
)

# 实战示例
user_proxy.initiate_chat(
    assistant,
    message="分析这份数据"
)

# Agent每轮都会停下来，问人类：
"""
Round 1:
Assistant: "我看到数据，分析计划是..."
Assistant: [停顿]
人类输入: "继续"

Round 2:
Assistant: "正在分析..."
Assistant: [停顿]
人类输入: "看看结果"

Round 3:
Assistant: "分析结果：..."
Assistant: [停顿]
人类输入: "可以优化吗？"

Round 4:
Assistant: [优化]
Assistant: "任务完成"
人类输入: "好的"
"""
```

---

#### 5. 代码执行与沙箱

```python
# 代码执行配置
code_execution_config = {
    # 工作目录
    "work_dir": "./agent_workspace",
    
    # 使用Docker沙箱（安全）
    "use_docker": True,
    
    # Docker镜像
    "docker_image": "python:3.9",
    
    # 超时时间
    "timeout": 60
}

user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    code_execution_config=code_execution_config
)

# Agent生成的代码会在Docker沙箱中执行
# 安全隔离，不会影响主机系统

# 执行流程：
"""
Assistant: "我来写代码..."
Assistant: 
```python
import requests
data = requests.get(url)
print(data.json())
```

User Proxy: [在Docker中执行代码]
User Proxy: "执行结果：{...}"
"""
```

---

#### 6. 实战案例：复杂问题求解

```python
# 多Agent协作解决复杂问题

problem_solver = autogen.AssistantAgent(
    name="problem_solver",
    system_message="你是问题解决专家，擅长分析和规划",
    llm_config={"model": "gpt-4"}
)

researcher = autogen.AssistantAgent(
    name="researcher",
    system_message="你是研究专家，擅长搜索和分析信息",
    llm_config={"model": "gpt-4"}
)

coder = autogen.AssistantAgent(
    name="coder",
    system_message="你是编程专家，擅长实现解决方案",
    llm_config={"model": "gpt-4"}
)

user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    human_input_mode="TERMINATE",
    code_execution_config={"work_dir": "workspace"}
)

# 群聊
group_chat = autogen.GroupChat(
    agents=[problem_solver, researcher, coder, user_proxy],
    messages=[]
)

manager = autogen.GroupChatManager(
    groupchat=group_chat
)

# 启动复杂任务
user_proxy.initiate_chat(
    manager,
    message="帮我分析股票数据并预测趋势"
)

# 对话协作流程：
"""
Round 1:
User: "分析股票数据并预测趋势"
Problem Solver: "任务分解：
1. 收集数据（Researcher）
2. 分析数据（Coder）
3. 建立预测模型（Coder）
"

Round 2:
Researcher: "开始收集数据..."
Researcher: [提供数据源]

Round 3:
Coder: [编写数据获取代码]
Coder: "代码已生成"
User Proxy: [执行代码]

Round 4:
Coder: [编写分析代码]
Coder: "分析完成"

Round 5:
Coder: [编写预测模型]
Coder: "预测模型已建立"
User Proxy: [执行模型]

Round 6:
Problem Solver: "综合分析结果..."
Problem Solver: "任务完成"
User Proxy（人类）: "确认"
"""
```

### 白话版答案

AutoGen 就是个**聊天式团队**，Agent互相聊天解决问题，人类随时插嘴。

**核心理念**：
- Agent间对话协作（不是命令）
- 人类可以随时介入监督
- Agent能生成并执行代码

---

**三大Agent类型**：

**1. Assistant Agent（助手）**

干活的Agent：
```
角色：助手
能力：解决问题、写代码
行为：有问必答，主动做事
```

**2. User Proxy Agent（人类代理）**

代表人类的Agent：
```
角色：人类代表
能力：执行代码、问人类意见
行为：
- ALWAYS模式：每轮都问人类
- TERMINATE模式：结束时问人类
- NEVER模式：全自动（不问人类）
```

**3. Group Chat Manager（群聊管理者）**

协调多个Agent：
```
角色：项目经理
能力：分配任务、协调对话
行为：决定哪个Agent回答
```

---

**对话协作机制**：

Agent不是命令式，是聊天式：

```
传统：
Manager → "你去干X" → Worker → 干X

AutoGen：
Agent A → "我有问题，谁能帮忙？"
Agent B → "我来帮你"
Agent C → "我也来提建议"
（像团队讨论）
```

---

**人类介入**：

人类随时插嘴：

```
ALWAYS模式（每轮问）：
Agent: "我有个想法..."
Agent: [停顿，等人类]
人类: "继续"
Agent: "那我继续..."

TERMINATE模式（结束问）：
Agent: "任务完成了"
Agent: [停顿，等人类确认]
人类: "好的"

NEVER模式（不问）：
Agent自己干，但限制轮数（别死循环）
```

---

**代码执行**：

Agent能写代码并执行：

```
Agent: "我来写代码..."
Agent: 
```python
import pandas as pd
data = pd.read_csv("data.csv")
print(data.head())
```

User Proxy: [在Docker沙箱中执行]
User Proxy: "执行结果：..."
```

在沙箱执行，不会搞坏你的系统。

---

**多Agent协作**：

像团队开会：

```
任务："分析股票数据"

Round 1:
问题专家：分解任务 → 收集数据、分析、预测

Round 2:
研究专家：收集数据源

Round 3:
编程专家：写数据获取代码

Round 4:
人类代理：执行代码

Round 5:
编程专家：写分析代码

Round 6:
问题专家：汇总结果

完成！
```

每个Agent各司其职，Manager协调。

---

**一句话**：
AutoGen = 对话协作 + 人类介入 + 代码执行 + 多Agent群聊 + 安全沙箱