# Agent 框架对比 - CrewAI 深度解析

## Q28: CrewAI 的多 Agent 协作机制是什么？如何实现角色分工？

### 专业版答案

#### CrewAI 核心概念

**CrewAI** 是专注于**多 Agent 协作**的框架，通过角色定义和任务分配实现团队协作。

核心理念：**一个 Crew（团队）= 多个 Agent（角色）+ Tasks（任务）**

---

#### 核心组件

**1. Agent（角色定义）**

```python
from crewai import Agent

# 定义研究员角色
researcher = Agent(
    role='高级研究员',
    goal='深入研究和分析信息',
    backstory="""你是一位资深研究员，擅长从海量信息中提取关键洞察。
    你的研究方法论严谨，擅长批判性思维。
    你总是追求客观、准确、全面的研究结论。""",
    
    # 能力和工具
    tools=[SearchTool(), AnalyzeTool()],
    llm=ChatOpenAI(model="gpt-4"),
    
    # 行为约束
    verbose=True,
    allow_delegation=False,  # 不允许委托任务给其他 Agent
    max_iter=10,             # 最大迭代次数
    max_rpm=100              # 每分钟最大请求次数（速率限制）
)

# 定义作家角色
writer = Agent(
    role='内容作家',
    goal='撰写高质量、引人入胜的内容',
    backstory="""你是一位资深作家，擅长将复杂概念转化为易懂的文字。
    你的写作风格简洁清晰，擅长讲故事。
    你总是追求内容的准确性、可读性和吸引力。""",
    
    tools=[WriteTool()],
    llm=ChatOpenAI(model="gpt-4"),
    
    verbose=True,
    allow_delegation=True,  # 允许委托（可以找研究员帮忙）
)

# 定义编辑角色
editor = Agent(
    role='编辑',
    goal='审核和优化内容质量',
    backstory="""你是一位严格但公正的编辑，擅长发现内容和逻辑问题。
    你注重细节，追求完美。
    你会提供具体的改进建议，而不是泛泛而谈。""",
    
    tools=[EditTool()],
    llm=ChatOpenAI(model="gpt-4"),
    
    verbose=True,
    allow_delegation=False
)
```

---

**2. Task（任务定义）**

```python
from crewai import Task

# 研究任务
research_task = Task(
    description="""
    研究 {topic} 的最新趋势和发展。
    
    要求：
    1. 收集至少 5 个权威来源
    2. 分析关键观点和争议点
    3. 总结主要趋势和预测
    4. 提出研究结论
    """,
    
    expected_output="""
    一份研究报告，包含：
    - 关键发现摘要
    - 详细分析（含数据支撑）
    - 主要趋势列表
    - 参考来源
    """,
    
    agent=researcher,  # 分配给研究员
    tools=[SearchTool(), AnalyzeTool()]
)

# 写作任务
writing_task = Task(
    description="""
    基于 research_task 的研究结果，撰写一篇关于 {topic} 的文章。
    
    要求：
    1. 标题吸引人
    2. 结构清晰（引言、主体、结论）
    3. 语言简洁易懂
    4. 包含具体案例
    """,
    
    expected_output="""
    一篇 1000-2000 字的文章，Markdown 格式
    """,
    
    agent=writer,     # 分配给作家
    context=[research_task]  # 依赖研究任务的结果
)

# 编辑任务
editing_task = Task(
    description="""
    审核 writing_task 的输出，优化内容质量。
    
    要求：
    1. 检查逻辑连贯性
    2. 检查语言准确性
    3. 检查格式规范性
    4. 提供改进建议或直接修改
    """,
    
    expected_output="""
    最终版本的优质文章
    """,
    
    agent=editor,
    context=[writing_task]
)
```

---

**3. Crew（团队组建）**

```python
from crewai import Crew, Process

# 组建团队
crew = Crew(
    agents=[researcher, writer, editor],
    tasks=[research_task, writing_task, editing_task],
    
    # 执行流程
    process=Process.sequential,  # 串行执行：research → write → edit
    
    verbose=True,
    memory=True  # 启用团队记忆
)

# 启动团队
result = crew.kickoff()
```

---

#### 执行流程

**串行流程（Sequential）**

```
Task 1 → Agent 1 (researcher) → 完成
            ↓ (结果传递)
Task 2 → Agent 2 (writer) → 完成
            ↓ (结果传递)
Task 3 → Agent 3 (editor) → 完成
            ↓
最终结果
```

**特点**：
- 任务按顺序执行
- 后续任务可以使用前面任务的结果
- 每个任务由指定 Agent 负责

---

**并行流程（Hierarchical）**

```python
crew = Crew(
    agents=[researcher, writer1, writer2, editor],
    tasks=[research_task, writing_task1, writing_task2, editing_task],
    process=Process.hierarchical  # 层级流程
)
```

```
Manager Agent（自动创建）
    ↓
┌───┴───┬───────┬───────┐
│       │       │       │
Task1  Task2   Task3   Task4
↓       ↓       ↓       ↓
Agent1  Agent2  Agent3  Agent4
↓       ↓       ↓       ↓
结果1   结果2   结果3   结果4
        ↓       ↓       ↓
    ────┴───────┴───────┘
            ↓
        Manager汇总
            ↓
        最终结果
```

**特点**：
- 自动创建 Manager Agent 负责协调
- 任务可以并行执行
- Manager 汇总所有结果

---

#### Agent 交互机制

**1. 任务委托（Delegation）**

```python
# Writer 需要更多研究信息
writer_agent.ask_agent(
    agent=researcher_agent,
    question="请提供更多关于 {topic} 的背景信息"
)

# Researcher 回答
researcher_agent.respond(
    to_agent=writer_agent,
    answer="基于我的研究，{topic} 有以下背景..."
)
```

**2. 结果共享（Context）**

```python
# Task B 使用 Task A 的结果
Task(
    description="基于上一个任务的结果继续...",
    context=[task_a]  # Task B 可以访问 Task A 的输出
)
```

**3. 团队记忆（Team Memory）**

```python
crew = Crew(
    agents=[...],
    tasks=[...],
    memory=True  # 团队共享记忆
)

# 记忆内容：
# - 所有 Agent 的对话历史
# - 所有任务的执行结果
# - Agent 间的协作记录
```

---

#### 实战示例：生成研究报告

```python
from crewai import Agent, Task, Crew

# 1. 定义角色
researcher = Agent(
    role='研究员',
    goal='深入研究 AI 发展趋势',
    backstory='资深研究员，擅长数据分析和趋势预测',
    tools=[WebSearchTool(), DataAnalysisTool()],
    llm=ChatOpenAI(model="gpt-4")
)

analyst = Agent(
    role='分析师',
    goal='分析数据并提供洞察',
    backstory='数据分析专家，擅长发现隐藏模式',
    tools=[ChartTool(), StatisticsTool()],
    llm=ChatOpenAI(model="gpt-4")
)

writer = Agent(
    role='报告撰写者',
    goal='撰写专业研究报告',
    backstory='专业作家，擅长技术写作',
    tools=[MarkdownTool()],
    llm=ChatOpenAI(model="gpt-4")
)

# 2. 定义任务
research_task = Task(
    description="收集 2024 年 AI 领域的最新进展",
    expected_output="关键发现列表",
    agent=researcher
)

analysis_task = Task(
    description="分析 AI 发展趋势和影响",
    expected_output="趋势分析报告",
    agent=analyst,
    context=[research_task]
)

writing_task = Task(
    description="撰写完整的 AI 发展报告",
    expected_output="Markdown 格式的报告",
    agent=writer,
    context=[research_task, analysis_task]
)

# 3. 组建团队
crew = Crew(
    agents=[researcher, analyst, writer],
    tasks=[research_task, analysis_task, writing_task],
    process=Process.sequential,
    verbose=True
)

# 4. 执行
result = crew.kickoff()
print(result)
```

### 白话版答案

CrewAI 就是个**虚拟团队系统**，你定义角色、分配任务，它们自己协作。

**核心概念**：

1. **Agent = 角色**
   - 研究员：负责收集信息
   - 作家：负责写内容
   - 编辑：负责审核质量

2. **Task = 任务**
   - 研究任务：交给研究员
   - 写作任务：交给作家（能用研究员的结果）
   - 编辑任务：交给编辑（能用作家写的文章）

3. **Crew = 团队**
   - 把角色和任务组合起来
   - 定义执行流程（串行 or 并行）

---

**咋工作的？**

**串行流程**（逐个干）：

```
研究员 → 收集信息 → 完成
  ↓（结果传给作家）
作家 → 写文章 → 完成
  ↓（结果传给编辑）
编辑 → 审稿 → 完成
  ↓
最终文章
```

每个人干完自己的活，把结果传给下一个人。

**并行流程**（同时干）：

```
Manager Agent（老板）
    ↓
同时派活给：
- 研究员 → 收集信息
- 作家1 → 写第一部分
- 作家2 → 写第二部分
- 编辑 → 审稿

所有结果汇给 Manager
    ↓
Manager 汇总整理
    ↓
最终结果
```

多人同时干活，老板汇总。

---

**角色咋定义？**

```python
研究员 = Agent(
    role="资深研究员",
    goal="深入研究，提取关键洞察",
    backstory="你是一位严谨的研究员，擅长批判性思维...",
    tools=[搜索工具, 分析工具],
    llm=GPT-4
)
```

关键要素：
- **role**：角色名称（研究员、作家、编辑）
- **goal**：目标（研究、写作、审核）
- **backstory**：背景故事（决定行为风格）
- **tools**：能用的工具
- **llm**：用的大模型

---

**任务咋定义？**

```python
研究任务 = Task(
    description="研究 AI 最新趋势",
    expected_output="关键发现列表",
    agent=researcher,  # 交给研究员
    tools=[搜索工具]
)
```

关键要素：
- **description**：任务描述
- **expected_output**：期望输出格式
- **agent**：分配给谁
- **context**：能用哪些前置任务的结果

---

**协作机制**：

1. **委托**：
   ```
   作家需要更多信息 → 问研究员
   研究员 → 回答作家
   ```

2. **共享结果**：
   ```
   研究任务完成 → 结果传给写作任务
   作家能用研究员的结果写文章
   ```

3. **团队记忆**：
   ```
   所有对话、所有结果、所有协作都记录
   团队成员都能访问
   ```

---

**一句话**：
CrewAI = 定义角色 + 分配任务 + 流程控制 + 团队协作 + 结果共享