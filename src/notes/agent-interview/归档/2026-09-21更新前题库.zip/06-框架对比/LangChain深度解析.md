# Agent 框架对比 - 深度解析

## Q24: LangChain 的核心设计理念是什么？有哪些优缺点？

### 专业版答案

#### 设计理念

**LangChain 的核心思想**：**组件化 + 链式组合**

将 LLM 应用分解为可复用的组件，通过"链（Chain）"组合起来。

```
Component A → Component B → Component C → Output
```

#### 核心组件

**1. Models（模型）**
```python
from langchain.llms import OpenAI
from langchain.chat_models import ChatOpenAI

llm = OpenAI(model="gpt-3.5-turbo")
chat_model = ChatOpenAI(model="gpt-4")
```

**2. Prompts（提示模板）**
```python
from langchain.prompts import PromptTemplate, ChatPromptTemplate

# 文本模板
template = PromptTemplate.from_template("""
你是{role}，请回答{question}
""")

# 聊天模板
chat_template = ChatPromptTemplate.from_messages([
    ("system", "你是{role}"),
    ("user", "{question}")
])
```

**3. Chains（链）**
```python
from langchain.chains import LLMChain, SequentialChain

# 单步链
chain = LLMChain(llm=llm, prompt=template)

# 多步链（串行）
sequential_chain = SequentialChain(
    chains=[chain1, chain2, chain3],
    input_variables=["input"],
    output_variables=["output"]
)
```

**4. Tools（工具）**
```python
from langchain.tools import Tool

search_tool = Tool(
    name="Search",
    func=search_function,
    description="搜索网络信息"
)

calculator_tool = Tool(
    name="Calculator",
    func=calculate_function,
    description="计算数学表达式"
)
```

**5. Agents（智能体）**
```python
from langchain.agents import create_openai_functions_agent, AgentExecutor

# 创建 Agent
agent = create_openai_functions_agent(llm, tools, prompt)

# Agent 执行器
agent_executor = AgentExecutor(agent=agent, tools=tools)
```

**6. Memory（记忆）**
```python
from langchain.memory import ConversationBufferMemory, VectorStoreMemory

# 缓冲记忆（保留最近对话）
memory = ConversationBufferMemory()

# 向量记忆（长期记忆）
vector_memory = VectorStoreMemory(vectorstore=vector_db)
```

**7. Retrievers（检索器）**
```python
from langchain.retrievers import VectorStoreRetriever

retriever = VectorStoreRetriever(vectorstore=vector_db)

# RAG 流程
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever
)
```

---

#### 优点

| 维度 | 优势 |
|------|------|
| 灵活性 | 组件可自由组合，适应各种场景 |
| 生态 | 大量集成（向量数据库、工具、模型） |
| 可复用 | 组件独立，可在不同项目中复用 |
| 易上手 | 概念清晰，文档丰富 |
| 社区 | 活跃社区，持续更新 |

---

#### 缺点

| 维度 | 问题 |
|------|------|
| 抽象过度 | 概念太多，新手容易迷失 |
| 性能 | 链式调用开销大，不如直接调用 |
| 版本不稳定 | API 变动频繁，代码容易失效 |
| 调试难 | 链太长，定位问题困难 |
| Agent 能力弱 | Agent 模块不如 AutoGPT 强 |

---

#### 最佳实践

**何时用 LangChain？**

1. **RAG 应用**
   ```python
   # LangChain 的 RAG 非常成熟
   from langchain.chains import RetrievalQA
   
   qa = RetrievalQA.from_chain_type(
       llm=llm,
       retriever=retriever,
       return_source_documents=True
   )
   ```
   优点：现成的 RAG 链，配置简单

2. **简单 Agent**
   ```python
   # 工具明确的简单 Agent
   agent = create_openai_functions_agent(llm, tools, prompt)
   ```
   优点：快速搭建，适合原型

3. **数据处理链**
   ```python
   # 多步数据处理
   chain = SequentialChain(
       chains=[load_chain, process_chain, output_chain]
   )
   ```
   优点：流程清晰，易于维护

**何时不用 LangChain？**

1. **复杂自主 Agent**
   - LangChain 的 Agent 能力有限
   - 用 AutoGPT 或 CrewAI 更好

2. **性能敏感场景**
   - LangChain 抽象层开销大
   - 直接调用 LLM API 更快

3. **高度定制化场景**
   - LangChain 限制灵活性
   - 自己写代码更自由

---

#### 实战示例

```python
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain
from langchain.tools import Tool
from langchain.agents import create_openai_functions_agent, AgentExecutor
from langchain.memory import ConversationBufferMemory

# 1. 创建模型
llm = ChatOpenAI(model="gpt-4")

# 2. 创建工具
def search(query):
    return f"搜索结果：{query}"

search_tool = Tool(name="search", func=search, description="搜索")

# 3. 创建记忆
memory = ConversationBufferMemory(memory_key="chat_history")

# 4. 创建 Agent
prompt = ChatPromptTemplate.from_messages([
    ("system", "你是助手"),
    ("user", "{input}")
])

agent = create_openai_functions_agent(llm, [search_tool], prompt)

# 5. 执行
agent_executor = AgentExecutor(
    agent=agent,
    tools=[search_tool],
    memory=memory,
    verbose=True
)

result = agent_executor.invoke({"input": "帮我搜索天气"})
```

### 白话版答案

LangChain 就是个**乐高积木系统**，给你一堆组件，自己拼。

**核心思想**：
- 组件化：把功能拆成小块（模型、工具、记忆...）
- 链式组合：一块接一块，串成完整流程

**七大组件**：

1. **Models** = AI 大脑（GPT、Claude）
2. **Prompts** = 提示模板（填空题模板）
3. **Chains** = 流程链（A → B → C）
4. **Tools** = 工具（搜索、计算）
5. **Agents** = 智能体（会自己选工具）
6. **Memory** = 记忆（记住对话）
7. **Retrievers** = 检索器（找文档）

**优点**：
- 灵活：随便拼组合
- 生态好：啥都有现成的集成
- 文档多：容易上手
- 社区活跃：更新快

**缺点**：
- 概念太多：新手容易晕
- 抽象过度：性能不如直接调 API
- 版本不稳：API 经常变，代码容易挂
- 调试难：链太长，找不到问题在哪
- Agent 能力弱：不如 AutoGPT 强

**啥时候用？**
- RAG 应用：LangChain 的 RAG 很成熟，直接用
- 简单 Agent：工具明确的场景，快速搭原型
- 数据处理链：多步流程清晰，易于维护

**啥时候不用？**
- 复杂自主 Agent：用 AutoGPT 或 CrewAI
- 性能敏感：直接调 API，别走 LangChain 抽象层
- 高度定制：自己写代码更自由

**一句话**：
LangChain = 乐高积木 + 链式组合 + 灵活但慢 + 适合原型和 RAG