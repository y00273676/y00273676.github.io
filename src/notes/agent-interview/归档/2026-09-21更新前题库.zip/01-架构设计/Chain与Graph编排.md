# Agent 架构设计 - 基础概念（续）

## Q53: Agent 编排中 Chain (链式) 与 Graph (图式) 的区别是什么？

### 专业版答案

#### 1. Chain (链式编排)

*   **定义**: 线性的执行流，步骤 A -> B -> C -> D。
*   **适用场景**: 流程固定、逻辑简单的任务。
*   **特点**:
    *   容易构建和调试。
    *   缺乏灵活性，如果步骤 B 失败了，整个链条可能断裂。
    *   无法处理需要根据结果动态跳转的情况。

```mermaid
graph LR
    A[输入] --> B[步骤A]
    B --> C[步骤B]
    C --> D[步骤C]
    D --> E[输出]
    
    style A fill:#e3f2fd
    style E fill:#c8e6c9
```

```python
# Chain 示例 (LangChain 风格)
chain = prompt | model | output_parser
result = chain.invoke({"topic": "AI"})
# 固定流程：输入 -> 提示词 -> 模型 -> 解析
```

---

#### 2. Graph (图式编排)

*   **定义**: 基于状态机的非线性执行流，由节点 (Node) 和边 (Edge) 组成。节点可以是 LLM 调用、工具调用或条件判断。
*   **适用场景**: 复杂逻辑、需要循环、条件分支、自我纠错的任务。
*   **特点**:
    *   **条件分支 (Conditional Edge)**: 根据结果决定下一步（如：如果代码报错，走"重试"节点；如果通过，走"完成"节点）。
    *   **循环 (Cycle)**: 支持 Agent Loop（思考 -> 行动 -> 观察 -> 循环）。
    *   **状态共享 (Shared State)**: 节点间通过状态图共享数据。

```mermaid
graph TB
    A[输入] --> B[Agent节点]
    B --> C{路由判断}
    C -->|继续| D[工具节点]
    C -->|重试| B
    C -->|完成| E[输出]
    D --> B
    
    style A fill:#e3f2fd
    style B fill:#ffcc80
    style C fill:#fff9c4
    style D fill:#a5d6a7
    style E fill:#c8e6c9
```

---

#### 3. 核心区别对比

| 维度 | Chain (链式) | Graph (图式) |
| :--- | :--- | :--- |
| **流向** | 单向，线性 | 多向，支持循环和分支 |
| **逻辑** | 固定的 Pipeline | 动态的状态机 |
| **容错** | 差 (断链) | 强 (自动回退/重试) |
| **复杂度** | 低 | 高 |
| **代表框架** | LangChain (Chains) | LangGraph, AutoGen (GroupChat) |

### 白话版答案

**Chain (链式)** 就像**流水线作业**，**Graph (图式)** 就像**交通导航**。

*   **Chain**:
    *   第一步洗菜，第二步切菜，第三步炒菜。
    *   必须按顺序来，不能跳步。如果切菜的时候发现刀钝了（报错），流水线就卡住了。
    *   适合简单、标准的活。

*   **Graph**:
    *   有红绿灯，有岔路口。
    *   走到切菜这一步，检查刀：
        *   刀钝了？-> 走"磨刀"的回路，磨完再回来切。
        *   刀没钝？-> 继续走"炒菜"的路。
    *   Agent 的核心能力（思考 - 行动 - 观察）本质上就是一个图（Loop），所以构建复杂的 Agent 必须用 Graph。

**一句话总结**：
Chain 是死的，一条路走到黑；Graph 是活的，能根据情况自动转弯、倒车、重头再来。复杂的 Agent 开发必须掌握 Graph 编排。